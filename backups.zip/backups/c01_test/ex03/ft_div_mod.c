/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/27 10:46:30 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/06/27 10:46:32 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
void ft_div_mod(int a, int b, int *div, int *mod)
{
	*div = a / b;
	*mod = a % b;
}

int main(){
  
  int a = 29 ;
  int b = 8 ;

  int div , mod ; 
  ft_div_mod( a , b , &div , &mod );

  printf("\n div = %d" , div );
  printf("\n mod = %d" , mod );

  return 0;
}