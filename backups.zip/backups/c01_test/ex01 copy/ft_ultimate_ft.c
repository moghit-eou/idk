/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_ft.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/27 10:11:56 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/06/27 10:11:57 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_ultimate_ft(int *********nbr)
{
	*********nbr = 42;
}

int main(){


   int x ; 

   int *one = &x ; 
   int **two = &one ; 
   int ***three = &two  ;
   int ****four = &three ;
   int *****five = &four ; 
   int ******six = &five ;
   int *******seven = &six ;
   int ********eight = &seven ;

   ft_ultimate_ft( &eight ) ;


    


	char first = x / 10 + '0' ; 
	char second = x % 10 + '0' ; 

	write (1 , &first , 1 ) ; 
	write ( 1 , &second , 1 ) ;
}