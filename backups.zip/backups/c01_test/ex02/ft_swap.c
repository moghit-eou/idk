/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_swap.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/27 10:22:54 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/06/27 10:22:56 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_swap(int *a, int *b)
{
	int	place_holder;

	place_holder = *a;
	*a = *b ;
	*b = place_holder;
}

 
int main(){
    
  int x = 10 ; 

  int y = 20 ; 

  printf("\nx = %d" , x ) ; 
  printf("\ny = %d" , y ) ; 
  
  ft_swap(&x , &y);
  printf("\n");
  printf("\nx = %d" , x ) ; 
  printf("\ny = %d" , y ) ; 
 





	return 0 ;
}
