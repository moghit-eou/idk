/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/27 11:27:10 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/06/27 11:27:14 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include <unistd.h>
#include <stdio.h>

void	ft_sort_int_tab(int *tab, int size)
{
	int place_holder;
	int	index;
	int	changed;

	changed = 1;
	while (changed != 0)
	{
		changed = 0 ;
		index = 0;
		while (index < size - 1)
		{
			if (tab[index] <= tab[index + 1])
			{
				index++;
				continue;
			}
			place_holder = tab[index];
			tab[index] = tab[index + 1];
			tab[index + 1] = place_holder;
 			changed = 1;
 			index++;
		}
	} 

}

int main(){

	int tab[] = {  0 , 1 , 2 , 10 , 0 , 2 , 2 , 6 } ; 
	int size = 8;
    
    for ( int i =  0 ; i < size ; i++ ) 
    	printf("%d " , tab[i] ) ; 

    printf("\n") ; 

     ft_sort_int_tab( tab , size ) ;

    for ( int i = 0 ; i < size ; i++ )
    	printf("%d " , tab[i] ) ; 

    return 0 ;
}