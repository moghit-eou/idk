/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/08 17:13:11 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/07/08 17:13:12 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int	*arr;
	int	index;

	if (max <= min)
		return (0);
	arr = (int *) malloc((max - min) * sizeof(int));
	if (arr == 0)
		return (0);
	index = 0;
	while (min < max)
	{
		arr[index] = min;
		min++;
		index++;
	}
	return (arr);
}
