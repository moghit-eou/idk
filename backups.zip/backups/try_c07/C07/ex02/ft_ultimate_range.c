/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/08 17:37:59 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/07/08 17:37:59 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdlib.h>

int	ft_ultimate_range(int **range, int min, int max)
{
	int	*arr;
	int	index;

	*range = 0;
	if (max <= min)
		return (0);
	arr = (int *) malloc((max - min) * sizeof(int));
	if (arr == 0)
		return (-1);
	index = 0;
	while (min + index < max)
	{
		arr[index] = min + index;
		index++;
	}
	*range = arr;
	return (max - min);
}
