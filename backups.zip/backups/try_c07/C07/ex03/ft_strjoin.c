/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/08 19:00:35 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/07/08 19:00:36 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	index;

	index = 0;
	while (str[index] != '\0')
		index++;
	return (index);
}

int	total_length(int size, char **strs, char *sep)
{
	int	total_size;
	int	index;

	total_size = ft_strlen(sep) * (size - 1);
	index = 0;
	while (index < size)
	{
		total_size += ft_strlen(strs[index]);
		index++;
	}
	return (total_size + 1);
}

void	concatenate(int *last_index, char *dest, char *src)
{
	int	index;

	index = 0;
	while (src[index] != '\0')
	{
		dest[*last_index] = src[index];
		index++;
		(*last_index)++;
	}
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	int		last_index;
	int		index;
	int		concatenated_size;
	char	*string;
	char	*empty_string;

	concatenated_size = total_length(size, strs, sep);
	string = (char *) malloc(concatenated_size * sizeof(char));
	empty_string = (char *) malloc(sizeof(char));
	if (size == 0)
		return (empty_string);
	if (string == 0)
		return (0);
	index = 0;
	last_index = 0;
	while (index < size - 1)
	{
		concatenate(&last_index, string, strs[index]);
		concatenate(&last_index, string, sep);
		index++;
	}
	concatenate(&last_index, string, strs[index]);
	string[last_index] = '\0';
	return (string);
}
