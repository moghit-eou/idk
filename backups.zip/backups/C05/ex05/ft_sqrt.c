/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sqrt.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/07 10:41:47 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/07/07 10:41:47 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_sqrt(int nb)
{
	int		left;
	int		right;
	long	middle;

	left = 0;
	right = 1e5;
	while (left <= right)
	{
		middle = (left + right) / 2;
		if (middle * middle == nb)
			return (middle);
		if (middle * middle < nb)
			left = middle + 1;
		else
			right = middle - 1;
	}
	return (0);
}
