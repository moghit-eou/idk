/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/06 22:05:02 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/07/06 22:11:59 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_factorial(int nb)
{
	int	answer;
	int	counter;

	if (nb < 0)
		return (0);
	answer = 1;
	counter = 1;
	while (counter <= nb)
	{
		answer *= counter;
		counter++;
	}
	return (answer);
}
