/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi_base.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/04 15:56:06 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/07/04 16:53:10 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
int	length_of_string(char *string)
{
	int	index;

	index = 0;
	while (string[index] != '\0')
		index++;
	return (index);
}

int	is_not_valid(char *string)
{
	int	index;
	int	right_index;

	if (length_of_string(string) <= 1)
		return (1);
	index = 0;
	while (string[index] != '\0')
	{
		right_index = index + 1;
		while (string[right_index] != '\0')
		{
			if (string[index] == string[right_index])
				return (1);
			right_index++;
		}
		if (string[index] == '-' || string[index] == '+')
			return (1);
		index++;
	}
	return (0);
}

int	value_of_character_in_base(char c, char *base)
{
	int	index ;

	index = 0 ;
	while (base[index] != '\0')
	{
		if (c == base[index])
			return (index);
		index++;
	}
	return (-1);
}

int	starting_index(char *str, int *is_negative)
{
	int	index;

	index = 0;
	*is_negative = 1;
	while (str[index] == 32 || (9 <= str[index] && str[index] <= 13))
		index++;
	while (str[index] == '-' || str[index] == '+')
	{
		if (str[index] == '-')
			(*is_negative) *= -1;
		index++;
	}
	return (index);
}

int	ft_atoi_base2(char *str, char *base)
{
	int	base_length;
	int	index;
	int	is_negative;
	int	number;
	int	exist;

	if (is_not_valid(base))
		return (0);
	base_length = length_of_string(base);
	index = starting_index(str, &is_negative);
	number = 0;
	while (str[index] != '\0')
	{
		exist = value_of_character_in_base(str[index], base);
		if (exist == -1)
			break ;
		number = number * base_length + exist;
		index++;
	}
	return (number * is_negative);
}
 


















