/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/03 18:02:33 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/07/03 18:02:34 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include<stdio.h>
int	is_space(char c)
{
	int	exist ;

	exist = 0;
	exist += (c == ' ');
	exist += (c == '\f');
	exist += (c == '\n');
	exist += (c == '\r');
	exist += (c == '\t');
	exist += (c == '\v');
	return (exist);
}

int	ft_atoi(char *str)
{
	int	index;
	int	is_negative;
	int	number;

	index = 0;
	is_negative = 0;
	number = 0;
	while (is_space(str[index]))
		index++;
	while (str[index] == '+' || str[index] == '-')
	{
		is_negative += (str[index] == '-');
		is_negative %= 2;
		index++;
	}
	while ('0' <= str[index] && str[index] <= '9')
	{
		number *= 10;
		number += (str[index] - '0');
		index++;
	}
	if (is_negative == 1)
		number *= -1;
	return (number);
}


int main()
{

	printf("%d\n", ft_atoi("		+-3423a343") );
	return 0;
}