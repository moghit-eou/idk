/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_base.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/04 12:59:34 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/07/04 12:59:36 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

int	length_of_string(char *string)
{
	int	index;

	index = 0;
	while (string[index] != '\0')
		index++;
	return (index);
}

int	is_not_valid(char *string)
{
	int	index;
	int	right_index;

	if (length_of_string(string) <= 1)
		return (1);
	index = 0;
	while (string[index] != '\0')
	{
		right_index = index + 1;
		while (string[right_index] != '\0')
		{
			if (string[index] == string[right_index])
				return (1);
			right_index++;
		}
		if (string[index] == '-' || string[index] == '+')
			return (1);
		index++;
	}
	return (0);
}

void	ft_putnbr_base(int nbr, char *base)
{
	char	c;
	int		base_length;

	if (is_not_valid(base))
		return ;
	base_length = length_of_string(base);
	if (nbr == -2147483648)
	{
		write (1, "-", 1);
		ft_putnbr_base(-(nbr / base_length), base);
		c = base[-(nbr % base_length)];
		write (1, &c, 1);
		return ;
	}
	if (nbr < 0)
	{
		write (1, "-", 1);
		nbr *= -1;
		ft_putnbr_base(nbr, base);
		return ;
	}
	if (nbr >= base_length)
		ft_putnbr_base(nbr / base_length, base);
	c = base[nbr % base_length];
	write(1, &c, 1);
}

int main()
{

	
	return 0 ;
}
