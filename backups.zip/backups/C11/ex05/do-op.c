/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   do-op.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/16 11:08:15 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/07/16 17:04:05 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	ft_putstr(char *str)
{
	int	index;

	index = 0;
	while (str[index] != '\0')
		write(1, &str[index++], 1);
}

void	ft_putnbr(int nb)
{
	char	c;

	if (nb == -2147483648)
	{
		write(1, "-2147483648", 11);
		return ;
	}
	if (nb < 0)
	{
		write (1, "-", 1);
		nb *= -1;
		ft_putnbr(nb);
		return ;
	}
	if (nb > 9)
		ft_putnbr(nb / 10);
	c = (nb % 10) + '0';
	write(1, &c, 1);
}

int	ft_atoi(char *str)
{
	int	index;
	int	is_negative;
	int	number;

	index = 0;
	is_negative = 0;
	number = 0;
	while (str[index] == 32 || (9 <= str[index] && str[index] <= 13))
		index++;
	while (str[index] == '+' || str[index] == '-')
	{
		is_negative += (str[index] == '-');
		is_negative %= 2;
		index++;
	}
	while ('0' <= str[index] && str[index] <= '9')
	{
		number *= 10;
		number += (str[index] - '0');
		index++;
	}
	if (is_negative == 1)
		number *= -1;
	return (number);
}

void	solve(int first, int second, char c)
{
	if (c == '+')
		ft_putnbr(first + second);
	else if (c == '/')
		ft_putnbr(first / second);
	else if (c == '-')
		ft_putnbr(first - second);
	else if (c == '*')
		ft_putnbr(first * second);
	else
		ft_putnbr(first % second);
}

int	main(int ac, char **av)
{
	int		first_number;
	int		second_number;
	char	op;

	if (ac != 4)
		return (0);
	first_number = ft_atoi(av[1]);
	second_number = ft_atoi(av[3]);
	op = av[2][0];
	if (op != '-' && op != '+' && op != '/' && op != '*' && op != '%')
	{
		write (1, "0\n", 2);
		return (0);
	}
	if (second_number == 0 && av[2][0] == '/')
		ft_putstr("Stop : division by zero");
	else if (second_number == 0 && av[2][0] == '%')
		ft_putstr("Stop : modulo by zero");
	else
		solve(first_number, second_number, av[2][0]);
	write (1, "\n", 1);
	return (0);
}
