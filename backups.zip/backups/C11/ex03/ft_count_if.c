/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_count_if.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/16 10:25:48 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/07/16 10:25:50 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_count_if(char **tab, int length, int (*f)(char*))
{
	int	index;
	int	counter;

	index = 0;
	counter = 0;
	while (index < length)
	{
		counter += ((*f)(tab[index]));
		index++;
	}
	return (counter);
}
