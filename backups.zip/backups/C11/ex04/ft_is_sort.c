/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_sort.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/16 10:40:34 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/07/16 10:50:30 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_is_sort(int *tab, int length, int (*f)(int, int))
{
	int	index;
	int	value;
	int	increasing;
	int	decreasing;

	index = 1;
	increasing = 1;
	decreasing = 1;
	while (index < length)
	{
		value = (*f)(tab[index - 1], tab[index]);
		if (value > 0)
			increasing = 0;
		if (value < 0)
			decreasing = 0;
		index++;
	}
	return (increasing == 1 || decreasing == 1);
}
