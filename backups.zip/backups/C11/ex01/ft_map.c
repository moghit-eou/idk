/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_map.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/16 10:09:19 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/07/16 10:09:21 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	*ft_map(int *tab, int length, int (*f)(int))
{
	int	*arr;
	int	index;

	index = 0;
	arr = (int *)malloc(length * sizeof(int));
	if (arr == 0)
		return (0);
	while (index < length)
	{
		arr[index] = (*f)(tab[index]);
		index++;
	}
	return (arr);
}
