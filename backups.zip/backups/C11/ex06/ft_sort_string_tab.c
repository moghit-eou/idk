/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_string_tab.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/16 17:16:46 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/07/16 19:56:28 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strcmp(char *s1, char *s2)
{
	int	index;

	index = 0;
	while (s1[index] != '\0' && s2[index] != '\0')
	{
		if (s1[index] != s2[index])
			return (s1[index] - s2[index]);
		index++;
	}
	if (s1[index] == '\0' && s2[index] == '\0')
		return (0);
	else if (s1[index] == '\0')
		return (-s2[index]);
	else
		return (s1[index]);
}

void	swap(char **s1, char **s2)
{
	char	*temp;

	temp = *s1;
	*s1 = *s2;
	*s2 = temp;
}

void	ft_sort_string_tab(char **tab)
{
	int	index;
	int	is_not_sorted;

	is_not_sorted = 1;
	while (is_not_sorted)
	{
		is_not_sorted = 0;
		index = 1;
		while (tab[index] != 0)
		{
			if (ft_strcmp(tab[index - 1], tab[index]) > 0)
			{
				swap(&tab[index - 1], &tab[index]);
				is_not_sorted = 1;
			}
			index++;
		}
	}
}
