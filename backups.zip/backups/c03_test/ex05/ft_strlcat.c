/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/02 21:16:38 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/07/02 21:16:39 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


 #include<stdio.h>
#include<string.h>
#define print_string(var) printf("%s = %s\n" , #var , var);
#define print_int(var) printf("%s = %d\n"  , #var , var);
#define print_char(var) printf("%s = %c\n" , #var, var);
#define new_line printf("\n");

unsigned int	length_of_string(char *src)
{
	int	index;

	index = 0;
	while(src[index] != '\0')
		index++;
	return (index);
}
unsigned int min(int a, int b)
{
	if( a > b)
		return b;
	else
		return a;
}
unsigned int ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int index;
 	unsigned int added_characters;
	unsigned int dest_length;
	unsigned int source_length;

	index = 0;
	dest_length = length_of_string(dest);
	source_length = length_of_string(src);
 	if (size < dest_length + 1)
		return (size + source_length);
	added_characters = size - dest_length - 1;
	print_int(added_characters)
	while (index < added_characters && src[index] != '\0')
	{	
		dest[dest_length + index] = src[index];
		index++;
	}
	dest[dest_length + index] = '\0';
	 
     return dest_length + source_length;

}


int main()
{
	 char *src = "123456" ;		 
	 printf("src = %s\n" , src ) ; 
	 for ( int i = 0 ; i <=  10 ; i++ ) 
	 {
	 	char dest[12] = "12345-";
	 	char des_[12] = "12345-";


	 	int n = strlcat ( dest , src , i ) ; 
 	    int x = ft_strlcat( des_ , src , i ) ;

 	    printf("size = %d\n" , i ) ;
 	    printf("correct = %d , dest = %s\n"  , n , dest) ;
 	    printf("solutio = %d , dest = %s\n"  , x , des_) ;
 	    new_line;


	 
	 }
 
	return 0;
}






