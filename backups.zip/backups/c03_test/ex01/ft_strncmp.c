/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/30 12:50:21 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/06/30 12:50:24 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include<stdio.h>
#include<string.h>
int	ft_strncmp(char *s1, char *s2, unsigned int n)
{
	unsigned int	index;

	index = 0;
	while (s1[index] != '\0' && s2[index] != '\0' && index < n)
	{
		if (s1[index] != s2[index])
			return (s1[index] - s2[index]);
		index++;

	}
	if (index == n)
		return (0);
	else if (s1[index] == s2[index])
		return (0);
	else if (s1[index] == '\0')
		return (-s2[index]);
	else
		return (s1[index]);
}

int main()
{
	char *first = "modghitdfd"; 
	char *second = "4modxghixdcdfd" ; 

	int n = 0 ; 
    printf("correct = %d" , strncmp( first , second , n ) ) ; 
    printf("\nsolutio = %d\n" , ft_strncmp( first , second , n ) );
}