/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/02 18:45:00 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/07/02 18:45:00 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include<stdio.h>
#include<string.h>
#define print_string(var) printf("%s = %s\n" , #var , var);
#define print_int(var) printf("%s = %d\n"  , #var , var);
#define print_char(var) printf("%s = %c\n" , #var, var);
#define new_line printf("\n");

int	substring_existence(char *str , char *to_find , int position )
{
	int	index;

	index = 0;
	while (to_find[index] != '\0')
	{
		if(str[index +position] == '\0')
			return (0);
		if(str[index + position] != to_find[index])
			return (0);
		index++;
	}
	return (1);
}

char	*ft_strstr(char *str, char *to_find)
{
	int index;

	index = 0;
	if(to_find[0] == '\0')
		return (str);
	while (str[index] != '\0')
	{
		if (str[index] == to_find[0] )
		{
			if(substring_existence(str, to_find, index))
				return (str + index);
		}
		index++;
	}
	return (0);
}

int main()
{
	 

	 char first[] = "moghitasfadosfas" ; 
	 char second[] = "os" ; 
  
 	 print_string( strstr ( first , second ) ) ; 
 	 print_string( ft_strstr(first , second )) ; 
	 new_line

 
	return 0;
}