/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/30 15:38:11 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/06/30 15:38:12 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include<stdio.h>
#include<string.h>
#define print_string(var) printf("%s = %s\n" , #var , var);
#define print_int(var) printf("#%s = %d\n"  , #var , var);
#define print_char(var) printf("#%s = %c\n" , #var, var);
#define new_line printf("\n");
char	*ft_strcat(char *dest, char *src)
{
	int	index;
	int second_index;

	index = 0;
	second_index = 0;
	while (dest[index] != '\0')
		index++;
	while (src[second_index] != '\0')
	{
		dest[index] = src[second_index];
		second_index++;
		index++;
	}
	dest[index] = '\0';
	return (dest);
}

int main()
{
	int n = 20 ;
	char dest[13] = "12345-";
	char dest1[14] = "12345-";
	char *src = "moghit";
	int x = 10 ;
	 
	/*
	    size(src) = 20 ; 
	    dest has 10 characters ;

	    so dest size should be atleast ( 10 + 20 + 1 ) for null characeters
	*/

	print_string(dest);
	print_string(dest1);
	print_string(src);

	ft_strcat( dest , src ) ; 
	
	new_line;
	print_string( dest ) ; 
	print_string( dest1) ;
	print_string(src);

	new_line;

	strcat( dest1, src ) ;

	print_string(dest)
	print_string(dest1);
	print_string(src);


 
	return 0;
}