/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/02 18:25:48 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/07/02 18:25:49 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include<stdio.h>
#include<string.h>
#define print_string(var) printf("%s = %s\n" , #var , var);
#define print_int(var) printf("%s = %d\n"  , #var , var);
#define print_char(var) printf("%s = %c\n" , #var, var);
#define new_line printf("\n");
char *ft_strncat(char *dest, char *src, unsigned int nb)
{
	 unsigned int	index;
	 unsigned int second_index;

	index = 0;
	second_index = 0;
	while (dest[index] != '\0')
		index++;
	while (src[second_index] != '\0' && second_index < nb)
	{
		dest[index] = src[second_index];
		second_index++;
		index++;
	}
	dest[index] = '\0';
	return (dest);
}

int main()
{
	 for ( int n = 0 ; n <= 20 ; n++ ) 
	 {
	 	char dest[13] = "12345-";
		char dest1[14] = "12345-";
		char *src = "moghit";
 

	    print_int(n);
		ft_strncat( dest , src , n ) ; 
		print_string( dest ) ; 
 		strncat( dest1, src , n) ;
 		print_string(dest1);
 		new_line;
	 }
 

 
	return 0;
}