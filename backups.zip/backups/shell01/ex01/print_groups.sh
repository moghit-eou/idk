id -G -n $FT_USER | tr ' ' ','
