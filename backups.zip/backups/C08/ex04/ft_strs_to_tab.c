/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strs_to_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/10 23:14:22 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/07/10 23:14:24 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include <stdlib.h>
struct s_stock_str
{
	int size ; 
	char * copy ; 
	char * str ; 
};
int	length_of_string(char *string)
{
	int	index;

	index = 0;
	while (string[index] != '\0')
		index++;
	return (index);
}

char	*ft_strdup(char *src)
{
	int		length;
	char	*ptr;
	int		index;

	length = length_of_string(src) + 1;
	ptr = (char *)malloc(length * sizeof(char));
	if (ptr == 0)
		return (0);
	index = 0;
	while (index < length)
	{
		ptr[index] = src[index];
		index++;
	}
	ptr[index] = '\0';
	return (ptr);
}

struct s_stock_str	*ft_strs_to_tab(int ac, char **av)
{
	struct s_stock_str	*arr;
	int					i;

	arr = (struct s_stock_str *) malloc((ac + 1) * sizeof (struct s_stock_str));
	i = 0;
	if (arr == 0)
		return (0);
	while (i < ac)
	{
		arr[i].size = length_of_string(av[i]);
		arr[i].str = av[i];
		arr[i].copy = ft_strdup(av[i]);
		i++;
	}
	arr[i].str = 0;
	arr[i].copy = 0;
	return (arr);
}
#include<stdio.h>
int main()
{

	char *tab[] = { "first" , "second" , "third" } ; 

	int n = 3 ; 
	struct s_stock_str * arr = ft_strs_to_tab( n , tab ) ;

	for ( int i =  0 ; i < n ; i++ ) 
		printf("%s\n" , arr[i].copy ) ;


	char *str = "ddd" ; 
 

	free ( arr ) ; 
	return 0;
}


