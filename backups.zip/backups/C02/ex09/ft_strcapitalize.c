/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/28 20:07:56 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/06/28 20:07:56 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	change(char *c)
{
	if ('a' <= *c && *c <= 'z')
		*c -= 32 ;
}

int	check_before(char c)
{
	if ('a' <= c && c <= 'z')
		return (0);
	if ('A' <= c && c <= 'Z')
		return (0);
	if ('0' <= c && c <= '9')
		return (0);
	return (1);
}

char	*ft_strcapitalize(char *str)
{
	int	index;

	change(&str[0]);
	index = 1;
	while (str[index] != '\0')
	{
		if ('A' <= str[index] && str[index] <= 'Z')
			str[index] += 32;
		if (check_before(str[index - 1]))
			change(&str[index]);
		index++;
	}
	return (str);
}
