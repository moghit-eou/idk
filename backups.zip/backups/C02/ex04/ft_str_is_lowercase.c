/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/28 11:59:38 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/06/28 11:59:39 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_lowercase(char *str)
{
	int	lowercase_only;
	int	index;

	lowercase_only = 1;
	index = 0;
	while (lowercase_only && str[index] != '\0')
	{
		if ('a' <= str[index] && str[index] <= 'z')
		{
			index++;
			continue ;
		}
		lowercase_only = 0;
	}
	return (lowercase_only);
}
