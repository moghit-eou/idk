/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/28 12:15:39 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/06/28 12:15:41 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

int	ft_str_is_printable(char *str)
{
	int	index;
	int	printable;

	index = 0;
	printable = 1;
	while (str[index] != '\0' && printable)
	{
		if (32 <= str[index] && str[index] <= 127)
		{
			index++;
			continue ;
		}
		printable = 0;
	}
	return (printable);
}
