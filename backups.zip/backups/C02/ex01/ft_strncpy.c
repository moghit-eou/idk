/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/29 17:43:28 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/06/29 17:48:18 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	str_size(char *str)
{
	unsigned int	index;

	index = 0;
	while (str[index] != '\0')
		index++;
	return (index);
}

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int		index;

	index = 0;
	while (index < n && src[index] != '\0')
	{
		dest[index] = src[index];
		index++;
	}
	if (str_size(src) < n)
	{
		while (index != n)
		{
			dest[index] = '\0';
			index++;
		}
	}
	return (dest);
}
