git ls-files --ignored --exclude-standard --other:s
