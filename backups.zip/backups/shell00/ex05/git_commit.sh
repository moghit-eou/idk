git log -5 --format="%H"
