/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   file.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/07 16:48:56 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/07/07 16:48:59 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>
#include <stdio.h>
int	check_diagonal(int arr[10][10], int n, int row, int col)
{
	int	r;
	int	c;

	r = row + 1;
	c = col - 1;
	while (r < n && c > -1)
	{
		if (arr[r][c])
			return (0);
		r++;
		c--;
	}
	r = row - 1;
	c = col - 1;
	while (r > -1 && c > -1)
	{
		if (arr[r][c])
			return (0);
		r--;
		c--;
	}
	return (1);
}

int	can_be_placed(int arr[10][10], int n, int row, int col)
{
	int	c;

	c = 0;
	while (c < col)
	{
		if (arr[row][c])
			return (0);
		c++;
	}
	return (check_diagonal(arr, n, row, col));
}

void	print_placements(int arr[10][10])
{
	int		r;
	int		c;
	char	character;

	c = 0;
	while (c < 10)
	{
		r = 0;
		while (r < 10)
		{
			if (arr[r][c])
			{
				character = r + '0';
				write(1, &character, 1);
				break ;
			}
			r++;
		}
		c++;
	}
	write(1, "\n", 1);
}

int	backtracking(int arr[10][10], int n, int col)
{
	int	row;
	int	answer;

	if (col == n)
	{
		for ( int i = 0 ; i < n ; i++ )
		{
			for ( int j = 0 ; j < n ; j++ ) {
				if ( arr[j][i] ) printf("Q");
				else printf(".");
			}
			printf("\n");
		}
		printf("\n================================\n");
		return (1);
	}
	answer = 0;
	row = 0;
	while (row < n)
	{
		if (can_be_placed(arr, n, row, col))
		{
			arr[row][col] = 1;
			answer += backtracking(arr, n, col + 1);
			arr[row][col] = 0;
		}
		row++;
	}
	return (answer);
}

int	ft_ten_queens_puzzle(void)
{
	int	arr[10][10];
	int	row;
	int	col;

	row = 0;
	col = 0;
	while (row < 10)
	{
		col = 0;
		while (col < 10)
		{
			arr[row][col] = 0;
			col++;
		}
		row++;
	}
	return (backtracking(arr, 10, 0));
}

int	main(void)
{
	ft_ten_queens_puzzle();
	return (0);
}
