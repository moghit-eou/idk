/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/03 13:34:58 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/07/03 13:35:01 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	length_of_string(char *src)
{
	int	index;

	index = 0;
	while (src[index] != '\0')
		index++;
	return (index);
}

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	unsigned int	index;
	unsigned int	added_characters;
	unsigned int	dest_length;
	unsigned int	source_length;

	index = 0;
	
	dest_length = length_of_string(dest);
	
	source_length = length_of_string(src);
	
	if (size < dest_length + 1)
		return (size + source_length);

	added_characters = size - dest_length - 1;
	
	while (index < added_characters && src[index] != '\0')
	{
		dest[dest_length + index] = src[index];
		index++;
	}
	
	dest[dest_length + index] = '\0';
	
	return (dest_length + source_length);
}
