/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/03 13:34:38 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/07/03 13:34:45 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	substring_existence(char *str, char *to_find, int position )
{
	int	index;

	index = 0;
	while (to_find[index] != '\0')
	{
		if (str[index + position] == '\0')
			return (0);
		if (str[index + position] != to_find[index])
			return (0);
		index++;
	}
	return (1);
}

char	*ft_strstr(char *str, char *to_find)
{
	int	index;

	index = 0;
	if (to_find[0] == '\0')
		return (str);
	while (str[index] != '\0')
	{
		if (str[index] == to_find[0])
		{
			if (substring_existence(str, to_find, index))
				return (str + index);
		}
		index++;
	}
	return (0);
}
