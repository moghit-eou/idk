/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/03 13:33:30 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/07/03 13:33:36 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

#include<stdlib.h>

#define print(n) printf("%s = %d\n" , #n , n ) ;
int main()
{

	int n = 4 ;

	int * arr = (int*) malloc(n * sizeof( int ) ) ;	

	for ( int i = 1 ; i <= n ; i++ ) 
		arr[i - 1] = i * 10 ; 

	n = 20 ;
  	for ( int i = 0 ; i <= n ; i++ ) 
		print( arr[i] );



	return 0 ;	
}