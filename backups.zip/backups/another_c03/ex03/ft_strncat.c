/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/03 13:34:21 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/07/03 13:34:27 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	unsigned int	index;
	unsigned int	second_index;

	index = 0;
	second_index = 0;
	while (dest[index] != '\0')
		index++;
	while (src[second_index] != '\0' && second_index < nb)
	{
		dest[index] = src[second_index];
		second_index++;
		index++;
	}
	dest[index] = '\0';
	return (dest);
}
