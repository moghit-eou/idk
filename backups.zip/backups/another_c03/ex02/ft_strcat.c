/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/03 13:34:06 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/07/03 13:34:10 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcat(char *dest, char *src)
{
	int	index;
	int	second_index;

	index = 0;
	second_index = 0;
	while (dest[index] != '\0')
		index++;
	while (src[second_index] != '\0')
	{
		dest[index] = src[second_index];
		second_index++;
		index++;
	}
	dest[index] = '\0';
	return (dest);
}
