/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_int_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/27 11:17:34 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/06/27 11:17:35 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_rev_int_tab(int *tab, int size)
{
	int	left_index;
	int	right_index;
	int	place_holder;

	left_index = 0;
	right_index = size - 1;
	while (left_index < right_index)
	{
		place_holder = tab[left_index];
		tab[left_index] = tab[right_index];
		tab[right_index] = place_holder;
		left_index++;
		right_index--;
	}
}
