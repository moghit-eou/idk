/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_int_tab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/27 11:27:10 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/06/27 11:27:14 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_sort_int_tab(int *tab, int size)
{
	int	place_holder;
	int	index;
	int	changed;

	changed = 1;
	while (changed != 0)
	{
		changed = 0 ;
		index = 0;
		while (index < size - 1)
		{
			if (tab[index] <= tab[index + 1])
			{
				index++;
				continue ;
			}
			place_holder = tab[index];
			tab[index] = tab[index + 1];
			tab[index + 1] = place_holder;
			changed = 1;
			index++;
		}
	}
}
