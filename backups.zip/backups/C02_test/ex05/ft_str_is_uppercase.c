/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/28 12:08:27 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/06/28 12:08:28 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include<stdio.h> 

int ft_str_is_uppercase(char *str)
{
	int uppercase_only;
	int index; 

	uppercase_only = 1;
	index = 0;
	while (uppercase_only && str[index] != '\0')
	{
		if('A' <= str[index] && str[index] <= 'Z')
		{
			index++;
			continue ;
		}
		uppercase_only = 0;
	}
	return (uppercase_only);
}

int main(){

	printf(" %d " , ft_str_is_uppercase( "" ) ) ; 
}