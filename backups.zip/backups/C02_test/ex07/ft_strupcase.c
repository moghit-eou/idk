/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strupcase.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/28 12:33:20 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/06/28 12:33:23 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include<stdio.h>

char	*ft_strupcase(char *str)
{
	int	index;

	index = 0;
	while (str[index] !='\0')
	{
		if ('a' <= str[index] && str[index] <='z')
			str[index] -=32;
		index++;
	}
	return (str);
}

int main(){


	char string[2] = "jj";
    
    printf("%lu\n", sizeof (string) );
	printf("%s" , ft_strupcase(string));
}