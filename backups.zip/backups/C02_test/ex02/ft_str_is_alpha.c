/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/28 11:31:05 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/06/28 11:31:06 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int ft_str_is_alpha(char *str)
{
	int exist;
	int index ; 
	int upper_case;
	int lower_case ;

	index = 0;
	exist = 1 ;

	while ( exist == 1 && str[index] != '\0')
	{
		lower_case = 0;
		upper_case = 0 ;
		if ('a' <= str[index] && str[index] <= 'z')
			lower_case = 1 ;

		if ( 'A' <= str[index] && str[index] <= 'Z' ) 
			upper_case = 1;

		if ( lower_case || upper_case )
		{
			index++;
			continue;
		}
		exist = 0 ;
	}

	return (exist);
}
void  print( char * string , int x )
{
	printf(" %s = %d \n" , string ,x  ) ;
}
int main(){
  
  char string[] = "" ;
  print( string , ft_str_is_alpha( string )) ;

  char *string1 = "mogh654it";
  print( string1 , ft_str_is_alpha( string1 )) ;

  char *string2 = "asfasdfLKJLKJ." ;
  print( string2 , ft_str_is_alpha( string2 )) ;


  char *string3 = ".sdfsd" ;
  print( string , ft_str_is_alpha( string3 )) ;


  return 0;


}




