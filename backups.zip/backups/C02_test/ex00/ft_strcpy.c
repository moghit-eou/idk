/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/28 10:05:17 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/06/28 10:05:18 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
#include <string.h>
char *ft_strcpy(char *dest, char *src)
{
	int		index;

	index = 0;
	while(src[index] != '\0')
	{
		dest[index] = src[index];
		index++;
	}
	dest[index] = '\0';
	return (dest);
}

void print(char *string){
	//printf("%s \n" , string ) ;
}
int main()
{
 	 
  
      char src []= "first" ; 
      char dest[] = "no" ;
      printf("%s\n" , dest ) ;
      print( ft_strcpy( dest , src )) ; 
      printf("\n%s " , dest ) ;
 	// print( strcpy ( second , first ) ) ; 


      
}