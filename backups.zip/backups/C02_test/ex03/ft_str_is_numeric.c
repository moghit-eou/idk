/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/28 11:48:38 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/06/28 11:48:39 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include <stdio.h>

int ft_str_is_numeric(char *str)
{
	int	exist;
	int	index;

	exist = 1;
	index = 0;

	while (str[index] != '\0' && exist == 1)
	{
		if ( '0' <= str[index] && str[index] <= '9' )
		{
			index++;
			continue ;
		}
		exist = 0;
	}
	return (exist);
}

int main()
{
	printf(" %d\n" , ft_str_is_numeric("0123456789" )) ;
}