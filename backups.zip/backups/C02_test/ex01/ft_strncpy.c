/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/28 10:33:55 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/06/28 10:33:56 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include <stdio.h>
#include <string.h> 
char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	int		index;

	while (index < n && src[index] != '0')
	{
		dest[index] = src[index];
		index++;
	}

	if ( index < n )
	{
		while(index < n)
		{
			dest[index] = '\0';
			index++;
		}
	}

	return (dest);
}

void print( char * string ) {

	  printf("%s\n" , string ) ; 
}
int main(){

   
   char dest[] = "mogddddddhit" ;
   char dest1[] = "mogddddddhit";
   
   int n =10;

   char *string = "1234";

   strncpy(dest , string , n) ;
   ft_strncpy(dest1 , string ,n );

   print( dest ) ;
   print( dest1) ; 



	return 0 ;
}