/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlowcase.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/28 12:42:19 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/06/28 12:42:22 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include<stdio.h>

char	*ft_strlowcase(char *str)
{
	int	index;

	index = 0;
	while (str[index] != '\0')
	{
		if('A' <= str[index] && str[index] <= 'Z')
			str[index] += 32;
		index++;
	}
	return str;
}


int main()
{
	char string[] = "";

	printf("%s\n" , ft_strlowcase(string));
}