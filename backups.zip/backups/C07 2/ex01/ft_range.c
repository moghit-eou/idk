/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/08 17:13:11 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/07/08 17:13:12 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdlib.h>

int	*ft_range(int min, int max)
{
	int	*arr;
	int	index;

	if (max <= min)
		return (0);
	arr = (int *) malloc((max - min) * sizeof(int));
	index = 0;
	while (min < max)
	{
		arr[index] = min;
		min++;
		index++;
	}
	return (arr);
}

#include<stdio.h>
int main()
{	
	int min = 10 ; 
	int max = 20 ; 
	int n = max - min ;
	int *arr = ft_range(min , max);

	for ( int i = 0 ; i < n ; i++ ){
		printf("arr[%d] = %d\n" , i + 1, arr[i] ) ;
	}
	return 0;
}