/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert_base2.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/09 15:10:52 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/07/09 15:10:53 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
int	length_of_string(char *string)
{
	int	index;

	index = 0;
	while (string[index] != '\0')
		index++;
	return (index);
}


void	ft_putnbr_base(int nbr, char *base ,char **dest,int *index)
{
	char	c;
	int		base_length;

	base_length = length_of_string(base);
	if (nbr == -2147483648)
	{
		*dest = "-2147483648";
		return ;
	}
	if (nbr < 0)
	{
		(*dest)[*index] = '-';
		(*index)++;
		nbr *= -1;
		ft_putnbr_base(nbr, base , dest , index);
		return ;
	}
	if (nbr >= base_length)
		ft_putnbr_base(nbr / base_length, base, dest, index);
	c = base[nbr % base_length];
	(*dest)[*index] = c ;
	(*index)++;
}

int length_number(int n)
{
	int counter = 0;
	if( n < 0 ){
		if (n == -2147483648)
		{
			n = -214748364;
			counter++;
		}
		counter++ ;
		n *= -1 ;
	}
	while ( n > 0 )
	{
		counter++;
		n /=10;
	}
	return counter;
}










