/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/26 16:12:07 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/06/26 16:12:09 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
void	ft_putnbr(int nb)
{
	char	c;

	if (nb == 0)
	{
		write (1, "0", 1);
		return ;
	}
	else if (nb == -2147483648)
	{
		write (1, "-2147483648", 11);
		return ;
	}
	if (nb < 0)
	{
		write (1, "-", 1);
		nb *= -1;
	}
	if (nb > 9)
		ft_putnbr(nb / 10);
	c = '0' + (nb % 10);
	write (1, &c, 1);
}

int main(){
    
    int x = ( 1 << 31 ) ;
     x -=5 ;
    for ( int i = 0 ; i < 10 ; i++ ) 
      printf("%d\n" , x + i ) ; 

	return 0 ;
}
