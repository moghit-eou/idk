/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/26 18:03:11 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/06/26 18:03:14 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_print_comb2(void)
{
	int		first_n;
	int		second_n;
	int		c;

	first_n = 0;
	while (first_n <= 98)
	{
		second_n = first_n + 1;
		while (second_n <= 99)
		{
			c = '0' + (first_n / 10);
			write (1, &c, 1);
			c = '0' + (first_n % 10);
			write (1, &c, 1);
			write (1, " ", 1);
			c = '0' + (second_n / 10);
			write(1, &c, 1);
			c = '0' + (second_n % 10);
			write (1, &c, 1);
			if (first_n != 98 || second_n != 99)
				write (1, ", ", 2);
			second_n++;
		}
		first_n++;
	}
}
