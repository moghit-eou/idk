/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_params.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/06 11:58:43 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/07/06 11:58:44 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	print_string(char *string)
{
	int	index;

	index = 0;
	while (string[index] != '\0')
	{
		write(1, &string[index], 1);
		index++;
	}
}

int	main(int argc, char *argv[])
{
	int	counter;

	counter = 1;
	while (counter < argc)
	{
		print_string(argv[counter]);
		write(1, "\n", 1);
		counter++;
	}
	return (0);
}
