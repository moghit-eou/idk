/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_program_name.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ael-ouaa <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/06 11:25:24 by ael-ouaa          #+#    #+#             */
/*   Updated: 2024/07/06 11:56:38 by ael-ouaa         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	print_string(char *string)
{
	int	index;

	index = 0;
	while (string[index] != '\0')
	{
		write(1, &string[index], 1);
		index++;
	}
}

int	main(int argc, char *argv[])
{
	int	counter;

	counter = 0;
	argc = 1;
	while (counter < argc)
	{
		print_string(argv[counter]);
		counter++;
	}
	write(1, "\n", 1);
	return (0);
}
